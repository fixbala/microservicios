<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
Bien venido <?php echo $_POST['name'] ?> a la página de prueba de docker en la UNIQUINDIO.

</body>
</html>