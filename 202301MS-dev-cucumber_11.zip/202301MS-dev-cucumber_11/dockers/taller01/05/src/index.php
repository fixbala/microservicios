<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
Bien venido a la página de prueba de docker en la UNIQUINDIO.
<form method="post" action="mensaje.php">
    <label for="name">Nombre:</label>
    <input type="text" name="name">
    <input type="submit" value="Aceptar">
</form>
</body>
</html>