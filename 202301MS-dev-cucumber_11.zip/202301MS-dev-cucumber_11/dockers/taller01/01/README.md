1. Instale docker en su equipo

R./

El proceso de instalación de docker puede ser encontrado [aquí](https://docs.docker.com/desktop/install/mac-install/)