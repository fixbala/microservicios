<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
Bien venido a la página de prueba de docker en la UNIQUINDIO.
<?php echo "Imprimiendo en una página PHP"; ?>
<img src="logo.png">
</body>
</html>