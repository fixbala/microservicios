package co.edu.uniquindio.ingesis.autenticacion.token;


import co.edu.uniquindio.ingesis.autenticacion.repository.Repository;

public interface TokenRepository extends Repository<Token> {
}
